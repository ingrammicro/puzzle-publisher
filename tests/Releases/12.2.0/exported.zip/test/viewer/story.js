var story = {
"docName": "test",
"docPath": "P_P_P",
"docVersion": "V_V_V",
"hasRetina": true,
"serverToolsPath":"/_tools/",
"disableHotspots": false,
"pages": [
$.extend(new ViewerPage(),{
"index": 0,
"image": "artboard.png",
"image2x": "artboard@2x.png",
"width": 520,
"height": 339,
"title": "Artboard",
'transAnimType': 0,
'layout' : {
	"offset": 40,
	"totalWidth": 1200,
	"numberOfColumns": 12,
	"columnWidth": 81.66666666666667,
	"gutterWidth": 20
},
'type': 'regular',
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 296,
			"y": 138,
			"width": 87,
			"height": 24
		},
		"isParentFixed": false,
		"page": 1,
		"index": 0
	},
	{
		"rect": {
			"x": 119,
			"y": 138,
			"width": 83,
			"height": 24
		},
		"isParentFixed": false,
		"page": 2,
		"index": 1
	}
],
})
,$.extend(new ViewerPage(),{
"index": 1,
"image": "modal2.png",
"image2x": "modal2@2x.png",
"width": 199,
"height": 127,
"title": "Modal2",
'transAnimType': 0,
'layout' : {
	"offset": 40,
	"totalWidth": 1200,
	"numberOfColumns": 12,
	"columnWidth": 81.66666666666667,
	"gutterWidth": 20
},
'type': 'modal',
'isModal': true,
'showShadow': 0,
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 52,
			"y": 74,
			"width": 81,
			"height": 24.000000000000007
		},
		"isParentFixed": false,
		"page": 3,
		"index": 0
	}
],
})
,$.extend(new ViewerPage(),{
"index": 2,
"image": "modal1.png",
"image2x": "modal1@2x.png",
"width": 199,
"height": 127,
"title": "Modal1",
'transAnimType': 0,
'layout' : {
	"offset": 40,
	"totalWidth": 1200,
	"numberOfColumns": 12,
	"columnWidth": 81.66666666666667,
	"gutterWidth": 20
},
'type': 'modal',
'isModal': true,
'showShadow': 0,
'fixedPanels': [],
'links' : [
	{
		"rect": {
			"x": 52,
			"y": 74,
			"width": 81,
			"height": 24
		},
		"isParentFixed": false,
		"page": 4,
		"index": 0
	}
],
})
,$.extend(new ViewerPage(),{
"index": 3,
"image": "overlay2.png",
"image2x": "overlay2@2x.png",
"width": 199,
"height": 206,
"title": "Overlay2",
'transAnimType': 0,
'layout' : {
	"offset": 40,
	"totalWidth": 1200,
	"numberOfColumns": 12,
	"columnWidth": 81.66666666666667,
	"gutterWidth": 20
},
'type': 'overlay',
'overlayByEvent': 0,
'overlayPin': 1,
'overlayPinHotspot': 0,
'overlayPinPage': 2,
overlayOverFixed:false,
overlayAlsoFixed:true,
overlayClosePrevOverlay:false,
'fixedPanels': [
	{
		"constrains": {
			"top": true,
			"bottom": false,
			"left": false,
			"right": true,
			"height": false,
			"width": false
		},
		"x": 33,
		"y": 69,
		"width": 131,
		"height": 114,
		"type": "float",
		"index": 0,
		"isFloat": true,
		"isFixedDiv": false,
		"divID": "",
		"links": [
			{
				"rect": {
					"x": 29,
					"y": 69,
					"width": 75,
					"height": 32
				},
				"isParentFixed": true,
				"page": 3,
				"index": 0
			},
			{
				"rect": {
					"x": 90,
					"y": 0,
					"width": 41,
					"height": 34
				},
				"isParentFixed": true,
				"page": 0,
				"index": 1
			}
		],
		"image": "overlay2-0.png",
		"image2x": "overlay2-0@2x.png",
		"shadow": "0px 2px 4px 0 #00000080 ",
		"shadowX": 4
	}
],
'links' : [],
'overlayRedirectTargetPage' : 0,
})
,$.extend(new ViewerPage(),{
"index": 4,
"image": "overlay.png",
"image2x": "overlay@2x.png",
"width": 131,
"height": 114,
"title": "Overlay",
'transAnimType': 0,
'layout' : {
	"offset": 40,
	"totalWidth": 1200,
	"numberOfColumns": 12,
	"columnWidth": 81.66666666666667,
	"gutterWidth": 20
},
'type': 'overlay',
'overlayShadow':'0px 2px 4px 0 #00000080 ',
'overlayShadowX':4,
'overlayByEvent': 0,
'overlayPin': 1,
'overlayPinHotspot': 0,
'overlayPinPage': 0,
overlayOverFixed:false,
overlayAlsoFixed:true,
overlayClosePrevOverlay:false,
'fixedPanels': [
	{
		"constrains": {
			"top": true,
			"bottom": false,
			"left": false,
			"right": true,
			"height": false,
			"width": false
		},
		"x": 0,
		"y": 0,
		"width": 131,
		"height": 114,
		"type": "float",
		"index": 0,
		"isFloat": true,
		"isFixedDiv": false,
		"divID": "",
		"links": [
			{
				"rect": {
					"x": 90,
					"y": 0,
					"width": 41,
					"height": 34
				},
				"isParentFixed": true,
				"page": 0,
				"index": 0
			},
			{
				"rect": {
					"x": 29,
					"y": 71,
					"width": 75,
					"height": 24
				},
				"isParentFixed": true,
				"page": 2,
				"index": 1
			}
		],
		"image": "overlay-0.png",
		"image2x": "overlay-0@2x.png",
		"shadow": "0px 2px 4px 0 #00000080 ",
		"shadowX": 4
	}
],
'links' : [],
'overlayRedirectTargetPage' : 0,
})
   ]
,"resolutions": [2],
"zoomEnabled": true,
"title": "test",
"startPageIndex": 0,
"layersExist": true,
"centerContent":  false,
"totalImages": 7,
"highlightLinks": false
,"iFrameSizeWidth": "400"
,"iFrameSizeHeight": "225"
}
